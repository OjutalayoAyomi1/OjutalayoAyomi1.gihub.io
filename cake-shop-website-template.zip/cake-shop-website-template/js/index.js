/*let firstname = document.regform.firstname.value;
let lastname = document.regform.lastname.value;

Allname =`${document.regform.firstname.value} ${document.regform.lastname.value}`

var allname = document.getElementById('allname');
//allname.innerHTML = Allname;
localStorage.Allname = `${document.regform.firstname.value}`;
//document.getElementById("allname").innerHTML = localStorage.Allname;

let finame = document.getElementById('fname');
finame.value = localStorage.Allname;
let cardname = document.getElementById('cardname');
cardname.value = localStorage.Allname;*/


/*finame.value = `${allname.innerHTML}`;
cardname.value = `${allname.innerHTML}`;*/

//allname.innerHTML = `${firstname} ${lastname}`;

//Save Data to Local Storage. 
//localStorage.setItem(key, value);
//Read Data from Local Storage. 
//let anyname = localStorage.getItem(key);
//Remove Data from Local Storage. 
//localStorage.removeItem(key);
//Remove All (Clear Local Storage) 
//localStorage.clear();
